import React from 'react';

const Index = ({ countries, onAddCountry, onEditCountry, onDeleteCountry }) => {
  
  // Función para obtener la clase CSS del continente
  const getContinentClass = (continent) => {
    const continentClasses = {
      'Africa': 'continent-africa',
      'Asia': 'continent-asia',
      'Europe': 'continent-europe',
      'North America': 'continent-north-america',
      'South America': 'continent-south-america',
      'Oceania': 'continent-oceania'
    };
    return continentClasses[continent] || 'bg-secondary';
  };

  // Función para contar países por continente
  const getCountriesByContinent = () => {
    const continentCounts = {};
    countries.forEach(country => {
      continentCounts[country.continent] = (continentCounts[country.continent] || 0) + 1;
    });
    return continentCounts;
  };

  // Función para manejar eliminación con confirmación
  const handleDelete = (country) => {
    if (window.confirm(`¿Estás seguro de eliminar ${country.name}?`)) {
      onDeleteCountry(country.id);
    }
  };

  const continentCounts = getCountriesByContinent();

  return (
    <div>
      {/* Estadísticas */}
      <div className="stats-container">
        <div className="row">
          <div className="col-md-3">
            <div className="stat-item">
              <div className="stat-number">{countries.length}</div>
              <div className="stat-label">Países Totales</div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="stat-item">
              <div className="stat-number">{16 - countries.length}</div>
              <div className="stat-label">Disponibles</div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="stat-item">
              <div className="stat-number">{Object.keys(continentCounts).length}</div>
              <div className="stat-label">Continentes</div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="stat-item">
              <div className="stat-number">
                {Math.max(...Object.values(continentCounts), 0)}
              </div>
              <div className="stat-label">Máx. por Continente</div>
            </div>
          </div>
        </div>
      </div>

      {/* Botón para agregar país */}
      <div className="navigation-buttons">
        <button 
          className="btn btn-custom btn-primary-custom"
          onClick={onAddCountry}
          disabled={countries.length >= 16}
        >
          <i className="bi bi-plus-circle me-2"></i>
          Agregar País
        </button>
        {countries.length >= 16 && (
          <div className="alert alert-info mt-2">
            <i className="bi bi-info-circle me-2"></i>
            Has alcanzado el máximo de 16 países
          </div>
        )}
      </div>

      {/* Tabla de países */}
      {countries.length > 0 ? (
        <div className="table-container">
          <div className="table-responsive">
            <table className="table table-striped table-hover">
              <thead>
                <tr>
                  <th>Número</th>
                  <th>Bandera</th>
                  <th>Nombre</th>
                  <th>Continente</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {countries.map((country, index) => (
                  <tr key={country.id}>
                    <td>
                      <span className="badge bg-primary rounded-pill">
                        {index + 1}
                      </span>
                    </td>
                    <td>
                      <img 
                        src={country.flag} 
                        alt={`Bandera de ${country.name}`}
                        className="country-flag"
                        onError={(e) => {
                          e.target.src = 'https://via.placeholder.com/50x35?text=?';
                        }}
                      />
                    </td>
                    <td>
                      <strong>{country.name}</strong>
                    </td>
                    <td>
                      <span className={`continent-badge ${getContinentClass(country.continent)}`}>
                        {country.continent}
                      </span>
                    </td>
                    <td>
                      <div className="btn-group" role="group">
                        <button 
                          className="btn btn-sm btn-custom btn-warning-custom"
                          onClick={() => onEditCountry(country)}
                          title="Editar país"
                        >
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button 
                          className="btn btn-sm btn-custom btn-danger-custom"
                          onClick={() => handleDelete(country)}
                          title="Eliminar país"
                        >
                          <i className="bi bi-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="text-center py-5">
          <i className="bi bi-globe display-1 text-muted mb-3"></i>
          <h3 className="text-muted">No hay países agregados</h3>
          <p className="text-muted">Comienza agregando tu primer país</p>
        </div>
      )}

      {/* Información sobre países por continente */}
      {Object.keys(continentCounts).length > 0 && (
        <div className="mt-4">
          <h5 className="mb-3">Distribución por Continente:</h5>
          <div className="row">
            {Object.entries(continentCounts).map(([continent, count]) => (
              <div key={continent} className="col-md-2 mb-2">
                <div className="text-center">
                  <span className={`continent-badge ${getContinentClass(continent)}`}>
                    {continent}
                  </span>
                  <div className="small text-muted mt-1">
                    {count}/4 países
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Index;