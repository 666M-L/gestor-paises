import React, { useState, useEffect } from 'react';
import Index from './index.jsx';
import Form from './views/Form.jsx';

function App() {
  const [currentView, setCurrentView] = useState('index');
  const [countries, setCountries] = useState([]);
  const [editingCountry, setEditingCountry] = useState(null);

  // Cargar países desde localStorage al iniciar
  useEffect(() => {
    const savedCountries = localStorage.getItem('countries');
    if (savedCountries) {
      setCountries(JSON.parse(savedCountries));
    }
  }, []);

  // Guardar países en localStorage cuando cambie la lista
  useEffect(() => {
    localStorage.setItem('countries', JSON.stringify(countries));
  }, [countries]);

  // Función para agregar país
  const addCountry = (newCountry) => {
    const countryWithId = {
      ...newCountry,
      id: Date.now(), // ID único basado en timestamp
    };
    setCountries(prev => [...prev, countryWithId]);
  };

  // Función para actualizar país
  const updateCountry = (updatedCountry) => {
    setCountries(prev => 
      prev.map(country => 
        country.id === updatedCountry.id ? updatedCountry : country
      )
    );
    setEditingCountry(null);
  };

  // Función para eliminar país
  const deleteCountry = (countryId) => {
    setCountries(prev => prev.filter(country => country.id !== countryId));
  };

  // Función para iniciar edición
  const startEdit = (country) => {
    setEditingCountry(country);
    setCurrentView('form');
  };

  // Función para cancelar edición
  const cancelEdit = () => {
    setEditingCountry(null);
    setCurrentView('index');
  };

  // Navegación entre vistas
  const navigateToForm = () => {
    setEditingCountry(null);
    setCurrentView('form');
  };

  const navigateToIndex = () => {
    setEditingCountry(null);
    setCurrentView('index');
  };

  return (
    <div className="container-fluid">
      <div className="main-container">
        <div className="app-header">
          <h1>
            <i className="bi bi-globe-americas me-3"></i>
            Gestor de Países
          </h1>
          <p>Evaluación Sumativa 4 - Programación Front End</p>
        </div>

        {currentView === 'index' ? (
          <Index
            countries={countries}
            onAddCountry={navigateToForm}
            onEditCountry={startEdit}
            onDeleteCountry={deleteCountry}
          />
        ) : (
          <Form
            countries={countries}
            editingCountry={editingCountry}
            onAddCountry={addCountry}
            onUpdateCountry={updateCountry}
            onCancel={cancelEdit}
            onNavigateToIndex={navigateToIndex}
          />
        )}
      </div>
    </div>
  );
}

export default App;