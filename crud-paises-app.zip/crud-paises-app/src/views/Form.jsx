import React, { useState, useEffect } from 'react';

const Form = ({ countries, editingCountry, onAddCountry, onUpdateCountry, onCancel, onNavigateToIndex }) => {
  const [countryName, setCountryName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Cargar datos del país en edición
  useEffect(() => {
    if (editingCountry) {
      setCountryName(editingCountry.name);
    }
  }, [editingCountry]);

  // Función para buscar país en la API
  const searchCountry = async (name) => {
    try {
      const response = await fetch(`https://restcountries.com/v3.1/name/${name}?fullText=true`);
      
      if (!response.ok) {
        throw new Error('País no encontrado');
      }
      
      const data = await response.json();
      
      if (data.length === 0) {
        throw new Error('País no encontrado');
      }
      
      const country = data[0];
      
      return {
        name: country.name.common,
        continent: country.continents[0],
        flag: country.flags.svg || country.flags.png,
        originalName: name // Guardamos el nombre original buscado
      };
    } catch (error) {
      throw new Error('País no encontrado o error en la API');
    }
  };

  // Función para validar límites
  const validateLimits = (countryData) => {
    const errors = [];
    
    // Verificar límite total (16 países)
    if (!editingCountry && countries.length >= 16) {
      errors.push('Ya has alcanzado el máximo de 16 países');
    }
    
    // Verificar países duplicados
    const isDuplicate = countries.some(existing => 
      existing.name.toLowerCase() === countryData.name.toLowerCase() && 
      (!editingCountry || existing.id !== editingCountry.id)
    );
    
    if (isDuplicate) {
      errors.push('Este país ya está en la lista');
    }
    
    // Verificar límite por continente (4 países por continente)
    const continentCount = countries.filter(country => 
      country.continent === countryData.continent &&
      (!editingCountry || country.id !== editingCountry.id)
    ).length;
    
    if (continentCount >= 4) {
      errors.push(`Ya tienes 4 países de ${countryData.continent}. Máximo permitido por continente.`);
    }
    
    return errors;
  };

  // Función para manejar el envío del formulario
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!countryName.trim()) {
      setError('Por favor, ingresa el nombre de un país');
      return;
    }
    
    setLoading(true);
    setError('');
    setSuccess('');
    
    try {
      // Buscar el país en la API
      const countryData = await searchCountry(countryName.trim());
      
      // Validar límites
      const validationErrors = validateLimits(countryData);
      if (validationErrors.length > 0) {
        setError(validationErrors.join('. '));
        setLoading(false);
        return;
      }
      
      // Agregar o actualizar país
      if (editingCountry) {
        onUpdateCountry({
          ...editingCountry,
          name: countryData.name,
          continent: countryData.continent,
          flag: countryData.flag
        });
        setSuccess('País actualizado exitosamente');
      } else {
        onAddCountry(countryData);
        setSuccess('País agregado exitosamente');
      }
      
      // Limpiar formulario
      setCountryName('');
      
      // Navegar de vuelta después de 2 segundos
      setTimeout(() => {
        onNavigateToIndex();
      }, 2000);
      
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  // Función para obtener estadísticas actuales
  const getStats = () => {
    const continentCounts = {};
    countries.forEach(country => {
      continentCounts[country.continent] = (continentCounts[country.continent] || 0) + 1;
    });
    
    return {
      total: countries.length,
      available: 16 - countries.length,
      continentCounts
    };
  };

  const stats = getStats();

  return (
    <div>
      {/* Botón para volver */}
      <div className="navigation-buttons">
        <button 
          className="btn btn-custom btn-primary-custom"
          onClick={onNavigateToIndex}
        >
          <i className="bi bi-arrow-left me-2"></i>
          Volver a la Lista
        </button>
      </div>

      {/* Estadísticas actuales */}
      <div className="stats-container">
        <div className="row">
          <div className="col-md-4">
            <div className="stat-item">
              <div className="stat-number">{stats.total}</div>
              <div className="stat-label">Países Actuales</div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="stat-item">
              <div className="stat-number">{stats.available}</div>
              <div className="stat-label">Espacios Disponibles</div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="stat-item">
              <div className="stat-number">{Object.keys(stats.continentCounts).length}</div>
              <div className="stat-label">Continentes Representados</div>
            </div>
          </div>
        </div>
      </div>

      {/* Formulario */}
      <div className="form-container">
        <h3 className="mb-4">
          <i className="bi bi-plus-circle me-2"></i>
          {editingCountry ? 'Editar País' : 'Agregar Nuevo País'}
        </h3>
        
        {editingCountry && (
          <div className="alert alert-info">
            <i className="bi bi-info-circle me-2"></i>
            Editando: <strong>{editingCountry.name}</strong>
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="countryName" className="form-label">
              Nombre del País *
            </label>
            <input
              type="text"
              className="form-control"
              id="countryName"
              value={countryName}
              onChange={(e) => setCountryName(e.target.value)}
              placeholder="Ej: Chile, Argentina, Brasil..."
              disabled={loading}
            />
            <div className="form-text">
              Ingresa el nombre exacto del país en inglés o español
            </div>
          </div>

          {/* Mostrar errores */}
          {error && (
            <div className="alert alert-danger" role="alert">
              <i className="bi bi-exclamation-triangle me-2"></i>
              {error}
            </div>
          )}

          {/* Mostrar éxito */}
          {success && (
            <div className="alert alert-success" role="alert">
              <i className="bi bi-check-circle me-2"></i>
              {success}
            </div>
          )}

          {/* Información sobre límites */}
          <div className="alert alert-info">
            <h6 className="mb-2">
              <i className="bi bi-info-circle me-2"></i>
              Límites del Sistema:
            </h6>
            <ul className="mb-0">
              <li>Máximo 16 países en total</li>
              <li>Máximo 4 países por continente</li>
              <li>No se permiten países duplicados</li>
            </ul>
          </div>

          {/* Distribución actual por continente */}
          {Object.keys(stats.continentCounts).length > 0 && (
            <div className="mb-4">
              <h6 className="mb-3">Distribución Actual por Continente:</h6>
              <div className="row">
                {Object.entries(stats.continentCounts).map(([continent, count]) => (
                  <div key={continent} className="col-md-6 mb-2">
                    <div className="d-flex justify-content-between align-items-center">
                      <span className="badge bg-primary">{continent}</span>
                      <span className={`badge ${count >= 4 ? 'bg-danger' : 'bg-success'}`}>
                        {count}/4
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Botones */}
          <div className="d-flex gap-2">
            <button 
              type="submit" 
              className="btn btn-custom btn-success-custom"
              disabled={loading || (!editingCountry && countries.length >= 16)}
            >
              {loading ? (
                <>
                  <span className="loading-spinner me-2"></span>
                  Buscando...
                </>
              ) : (
                <>
                  <i className="bi bi-save me-2"></i>
                  {editingCountry ? 'Actualizar País' : 'Agregar País'}
                </>
              )}
            </button>
            
            <button 
              type="button" 
              className="btn btn-custom btn-danger-custom"
              onClick={onCancel}
              disabled={loading}
            >
              <i className="bi bi-x-circle me-2"></i>
              Cancelar
            </button>
          </div>
        </form>

        {/* Información adicional */}
        <div className="mt-4">
          <h6 className="mb-2">
            <i className="bi bi-lightbulb me-2"></i>
            Consejos:
          </h6>
          <ul className="small text-muted">
            <li>Los nombres de países deben ser exactos (ej: "United States" no "USA")</li>
            <li>Puedes usar nombres en español o inglés</li>
            <li>La API buscará automáticamente la información oficial del país</li>
            <li>Si hay error, verifica la ortografía del nombre</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Form;