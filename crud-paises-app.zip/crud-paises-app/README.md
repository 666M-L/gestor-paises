# 🌍 Gestor de Países - Evaluación Sumativa 4

Este proyecto es una aplicación CRUD (Crear, Leer, Editar, Eliminar) desarrollada con **React.js + Vite**, que permite gestionar una lista de países utilizando datos en tiempo real desde la API [REST Countries](https://restcountries.com).

## 🚀 Funcionalidades

- ✅ Consultar países usando la API externa.
- ✅ Agregar nuevos países (máximo 16 en total).
- ✅ Máximo 4 países por continente.
- ✅ Edición del país (realiza nueva consulta a la API).
- ✅ Eliminar país del listado.
- ✅ Validación para evitar duplicados y límites.
- ✅ Persistencia con `localStorage`.
- ✅ Interfaz visual amigable con **Bootstrap** y **Bootstrap Icons**.
- ✅ Dos vistas: principal e ingreso/edición.

## 🗂️ Estructura del Proyecto

```
/src
│
├── index.jsx              # Vista principal (tabla)
├── App.jsx                # Controlador principal de vistas
├── main.jsx               # Punto de entrada de React
├── /views
│   └── Form.jsx           # Vista del formulario (agregar/editar)
└── /css
    └── styles.css         # Estilos personalizados
```

## 🎯 Reglas del sistema

- Máximo **16 países**.
- Máximo **4 países por continente**.
- **No se permiten duplicados**.
- Se debe ingresar el **nombre exacto** del país (en español o inglés).

## 🖼️ Tecnologías Utilizadas

- [React.js](https://reactjs.org/)
- [Vite](https://vitejs.dev/)
- [REST Countries API](https://restcountries.com/)
- [Bootstrap 5](https://getbootstrap.com/)
- [Bootstrap Icons](https://icons.getbootstrap.com/)

## 📦 Instalación

1. Clona este repositorio:
   ```bash
   git clone https://github.com/666M-L/gestor-paises.git
   cd gestor-paises
   ```

2. Instala las dependencias:
   ```bash
   npm install
   ```

3. Ejecuta la app en modo desarrollo:
   ```bash
   npm run dev
   ```

## 🌐 Deploy

Puedes subir este proyecto a [Vercel](https://vercel.com/) o [Netlify](https://netlify.com/).

---

## 👨‍💻 Autor

**Tu Nombre**  
Estudiante de Programación Front-End  
INACAP – Evaluación Sumativa 4

---

## 📄 Licencia

Este proyecto es de uso educativo y no tiene licencia comercial.
